export interface Image {
  id: string;
  url: string;
  category: string;
  createdAt: string;
}